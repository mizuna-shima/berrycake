<?php
/*
Plugin Name: WP Berrycake
Plugin URI: https://lanama.net/
Description: 名前変換スクリプトBerrycake.jsをWordPress全てのページで読み込みます。
Version: 1.1.1
Author: 島ミズナ
Author URI: https://lanama.net/
License: Custom License
*/

/*!
 * Berrycake.js
 * Berrycake.js License (Issued February 22, 2024)
 * Copyright (c) Mizuna Shima
 * Website: https://lanama.net/scripts/berrycake/
 * 
 * Subject to the conditions set forth below, anyone who obtains a copy of this script is granted permission to use it for commercial and non-commercial purposes free of charge.
 * Please adhere to the following usage rules:
 * 1. When used commercially or redistributed, significant parts must include the author's credit and the official distributor.
 * 2. Do not remove the credits and license text within the file.
 * 3. Do not sell the script, nor any product primarily based on this script.
 * 4. Do not use the saved data from this script for monetary claims or requests for goods.
 * Even if the user modifies this script, these rules must be followed.
 * 
 * The author or copyright owner of this script shall not be liable for any damages or issues under any contract, tort, or other liabilities, in any case.
 */

// 直接アクセスを防止
if (!defined('ABSPATH')) {
    exit;
}

// 管理メニューにカスタムページを追加
add_action('admin_menu', 'wp_berrycake_menu');
function wp_berrycake_menu() {
    add_menu_page(
        'WP Berrycake',             // ページのタイトル
        'WP Berrycake',             // メニューのタイトル
        'manage_options',           // 必要な権限
        'wp-berrycake',             // メニューのスラッグ
        'wp_berrycake_page',        // メニューがクリックされたときの関数
        plugin_dir_url(__FILE__) . 'admin/icon.png',  // アイコン画像のURL
        100                         // メニューの表示位置（設定よりも下）
    );
}

// プラグイン一覧に設定リンクを追加
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'wp_berrycake_action_links');
function wp_berrycake_action_links($links) {
    $settings_link = '<a href="admin.php?page=wp-berrycake">' . __('Settings') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}

// 管理ページのコンテンツ
function wp_berrycake_page() {
    include plugin_dir_path(__FILE__) . 'admin/editor-page.php';
}

// フォーム送信を処理
add_action('admin_post_save_wp_berrycake', 'save_wp_berrycake');
function save_wp_berrycake() {
    try {
        // Nonceを確認
        if (!isset($_POST['wp_berrycake_nonce']) || !wp_verify_nonce($_POST['wp_berrycake_nonce'], 'save_wp_berrycake')) {
            throw new Exception('Nonce verification failed');
        }

        // ユーザー権限を確認
        if (!current_user_can('manage_options')) {
            throw new Exception('Insufficient permissions');
        }

        // berrycake.jsファイルに保存
        if (isset($_POST['berrycake_js'])) {
            $berrycake_js = wp_unslash($_POST['berrycake_js']);
            file_put_contents(plugin_dir_path(__FILE__) . 'js/berrycake.js', mb_convert_encoding($berrycake_js, 'UTF-8', 'auto'));
        }

        // berrycake_recipe.confファイルに保存
        if (isset($_POST['berrycake_recipe_conf'])) {
            $berrycake_recipe_conf = wp_unslash($_POST['berrycake_recipe_conf']);
            file_put_contents(plugin_dir_path(__FILE__) . 'js/berrycake_recipe.conf', mb_convert_encoding($berrycake_recipe_conf, 'UTF-8', 'auto'));
        }

        // 成功メッセージ
        wp_safe_redirect(admin_url('admin.php?page=wp-berrycake&message=success'));
        exit;
    } catch (Exception $e) {
        // エラーメッセージ
        wp_safe_redirect(admin_url('admin.php?page=wp-berrycake&message=error&error=' . urlencode($e->getMessage())));
        exit;
    }
}

// フロントでカスタムJSを読み込む
add_action('wp_enqueue_scripts', 'enqueue_wp_berrycake_js');
function enqueue_wp_berrycake_js() {
    $berrycake_js_url = plugins_url('js/berrycake.js', __FILE__);

    wp_enqueue_script('berrycake-js', $berrycake_js_url, array(), null, true);
}

// カスタムCSSを追加してアイコンを調整
add_action('admin_enqueue_scripts', 'wp_berrycake_admin_styles');
function wp_berrycake_admin_styles() {
    wp_enqueue_style('wp_berrycake_admin_css', plugin_dir_url(__FILE__) . 'admin/wp-berrycake-admin.css');
}