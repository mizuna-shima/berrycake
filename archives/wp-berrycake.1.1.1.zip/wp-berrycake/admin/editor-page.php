<?php
// 直接アクセスを防止
if (!defined('ABSPATH')) {
    exit;
}

// berrycake.jsの現在のコンテンツを読み込む
$berrycake_js_path = plugin_dir_path(__FILE__) . '../js/berrycake.js';
$berrycake_js = file_exists($berrycake_js_path) ? mb_convert_encoding(file_get_contents($berrycake_js_path), 'UTF-8', 'auto') : '';

// berrycake_recipe.confの現在のコンテンツを読み込む
$berrycake_recipe_conf_path = plugin_dir_path(__FILE__) . '../js/berrycake_recipe.conf';
$berrycake_recipe_conf = file_exists($berrycake_recipe_conf_path) ? mb_convert_encoding(file_get_contents($berrycake_recipe_conf_path), 'UTF-8', 'auto') : '';

// メッセージの表示
if (isset($_GET['message'])) {
    if ($_GET['message'] == 'success') {
        echo '<div class="notice notice-success is-dismissible"><p>ファイルが正常に保存されました。</p></div>';
    } elseif ($_GET['message'] == 'error' && isset($_GET['error'])) {
        echo '<div class="notice notice-error is-dismissible"><p>エラーが発生しました: ' . esc_html($_GET['error']) . '</p></div>';
    } else {
        echo '<div class="notice notice-error is-dismissible"><p>エラーが発生しました。</p></div>';
    }
}
?>
<div class="wrap">
    <h1>WP Berrycake Editor</h1>
    <p>Berrycake.jsの使い方は配布サイトをご確認ください。</p>
    <a href="https://lanama.net/scripts/berrycake/" target="_blank">
        <img src="<?php echo plugin_dir_url(__FILE__); ?>banner_berrycake.png" alt="Berrycake.js" style="width: 200px; height: 40px;">
    </a>
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="save_wp_berrycake">
        <?php wp_nonce_field('save_wp_berrycake', 'wp_berrycake_nonce'); ?>
        <h2>berrycake_recipe.conf（デフォルトネームの設定）</h2>
        <p>デフォルト名は cake●= （●は半角数字）、ラベルはデフォルト名の数字と合うように label●= を設定します。</p>
        <textarea name="berrycake_recipe_conf" rows="20" cols="100" style="width: 100%;"><?php echo esc_textarea($berrycake_recipe_conf); ?></textarea>
        <br>
        <br>
        <p>デフォルトネームの設定項目がありますが、↑のberrycake_recipe.confの設定が使われるので無視してください。</p>
        <p>基本的には本体スクリプトの編集は不要ですが、こだわりがある方は編集して保存してください。</p>
        <h2>berrycake.js</h2>
        <textarea name="berrycake_js" rows="20" cols="100" style="width: 100%;"><?php echo esc_textarea($berrycake_js); ?></textarea>
        <?php submit_button('保存する'); ?>
    </form>
    <p>エラーが発生して保存ができないときは、FTPアプリ等を使用して新しいファイルを直接アップロードしてください。</p>
</div>
