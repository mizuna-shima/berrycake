/*!
 * Berrycake.js ver 1.4.0
 * Berrycake.js License (Issued February 22, 2024)
 * Copyright (c) Mizuna Shima
 * Website: https://lanama.net/scripts/berrycake/
 * 
 * Subject to the conditions set forth below, anyone who obtains a copy of this script is granted permission to use it for commercial and non-commercial purposes free of charge.
 * Please adhere to the following usage rules:
 * 1. When used commercially or redistributed, significant parts must include the author's credit and the official distributor.
 * 2. Do not remove the credits and license text within the file.
 * 3. Do not sell the script, nor any product primarily based on this script.
 * 4. Do not use the saved data from this script for monetary claims or requests for goods.
 * Even if the user modifies this script, these rules must be followed.
 * 
 * The author or copyright owner of this script shall not be liable for any damages or issues under any contract, tort, or other liabilities, in any case.
 */

// デフォルトネームと、フォーム自動出力時のラベル
// 設定ファイルを使わないときだけ編集してください
class BerrycakeName {
  static name = {
    cake1: "実小麦",
    cake2: "蜜花",
    cake3: "みこむぎ",
    cake4: "みつか",
  };
  static label = {
    label1: "苗字",
    label2: "名前",
    label3: "みょうじ",
    label4: "なまえ",
  }
  // この行は編集しない
  static getName = () => { return this.name;}; static getLabel = () => { if (typeof this.label !== 'undefined') {return this.label;}return {};};
}

class Berrycake {
  // 名前リスト設定ファイルを使う:1  使わない:0  使わない場合は↑のnameとlabelの一覧を編集してください。追加も可。
  static useConf = 1;
  // 名前リスト設定ファイルのファイルパス
  static nameList = 'berrycake_recipe.conf';
  // 登録ボタンのid
  static setNameId = 'cakeSet';
  // 一時登録ボタンのid
  static setSessionId = 'cakeSession';
  // 削除ボタンのId
  static unsetNameId = 'cakeUnset';
  // 一時登録の表記をするid
  static viewRegistSession = 'cakeSessionmsg';
  // 一時登録の際に表示できるメッセージ
  static sessionString = '一時登録しました';
  // 部分的に置換したい範囲の指定id
  static targetAreaId = 'berrycake';
  // 部分的に置換したい範囲のclass
  // classの場合、複数あっても1つ目のタグ内のみが変換対象です。
  // 上記のidで範囲を取得できたときはこのclass指定は無効になります。
  static targetAreaClass = 'berrycake';
  // 登録フォームを自動で出力する場合の指定id
  static formTargetId = 'cakeMix';
  // 登録フォームをシンプルな構造で出力する場合の指定class
  static formPlainClass = 'plain';
  // 自動出力フォームの登録ボタンの文字
  static autoSetNameStr = '登録';
  // 自動出力フォームの削除ボタンの文字
  static autoUnsetNameStr = '削除';
  // 変換回避タグのclass
  static replaceSkipClass = 'no_cake';
  // 登録できる最大文字数
  // この文字数を超える文字は「…」として変換されます。この機能を使用しない場合は0を設定します。
  static maxSize = 50;
  // 名前登録時、ブラウザの設定で「Web Storage」が使えないときにウィンドウを出すかどうか
  // 出す場合は1を設定します。
  static showStorageError = 0;
  // 追加したい対象タグ
  // p, li, ruby, rt, h1, h2, h3, h4, a, span, divタグの他に対象にしたいタグがあればこちらに。
  // 思わぬ動作をするかもしれないので、追加した場合は念入りに動作確認してください。
  addTag = [
    '',
    '',
    '',
  ];
  // localStorageまたはsessionStorageの保存キー
  static storageKeyName = 'berrycake';
  // カスタム用class共通
  static customCommonStr = 'cake_custom_';
  // カスタム用記号共通
  static customSymbol = 'cake_custom_symbol';
  // カスタム用数値共通
  static customNum = 'cake_custom_num';
  
  /******** 以降の行はシステム部分のため、触らないでください ********/

  
  static isErrored=!1;static replaceLimit=1e3;static customNumLimit=10;static customSymbolList=["……","ー","――","〰〰","〜","！","！　","、","。","・",",","，","☆","☆　","★","★　","♡","♡　","♪","♪　"];constructor(){this.mix={},this.cake={},this.label={},this.tmpBerrycake={},this.isSession=!1,this.cakeKeys={},this.targetNode=void 0,this.tags=["p","ruby","rt","h1","h2","h3","h4","h5","li","th","td","a","span","div"],this.regexPatterns={}}static async run(){try{const e=await Berrycake.initialize();if(Berrycake.isErrored)throw new Error("初期化に失敗しました。Initialization failed.");return e.initializeRegexPatterns(),e.setTagTarget(),e.addTagList(),e.start(),e.viewName(),e}catch(e){console.error("Error in Berrycake.run:",e)}}static async initialize(){const e=new Berrycake;try{this.useConf?await e.checkAndGetConf():e.addCakeNamesAndLabels(),e.cakeKeys=Object.keys(e.mix),e.createMixForm()}catch(e){console.error("Error initializing Berrycake:",e),Berrycake.isErrored=!0}return e}checkAndGetConf=()=>new Promise((async(e,t)=>{try{let t=this.checkAndShowBeforeErr();if(t)throw new Error(t);const a=Berrycake.getBerrycakeConfigPath(),r=await fetch(a);if(!r.ok)throw console.error("設定ファイルが読み込めません。"),new Error(`HTTP error! status: ${r.status}`);const s=await r.text();this.setNameAndLabel(s),e()}catch(e){console.error("Error checkAndGetConf Berrycake:",e),t(e)}}));extractNumber(e,t){const a=new RegExp(`^${t}(\\d+)$`),r=e.match(a);return r?r[1]:null}addCakeName(e,t){const a=this.extractNumber(e,"cake");null!==a&&(this.mix[`cake${a}`]=t)}addCakeLabel(e,t){const a=this.extractNumber(e,"label");null!==a&&(this.label[`label${a}`]=t)}addCakeNamesAndLabels(){const e=BerrycakeName.getName(),t=BerrycakeName.getLabel();Object.entries(e).forEach((([e,t])=>{e.startsWith("cake")&&this.addCakeName(e,t)}));0===Object.keys(t).length||Object.entries(t).forEach((([e,t])=>{e.startsWith("label")&&this.addCakeLabel(e,t)}))}static getFormattedDate(){const e=new Date;return`${e.getFullYear()}${String(e.getMonth()+1).padStart(2,"0")}${String(e.getDate()).padStart(2,"0")}`}static getBerrycakeConfigPath(){const e=Berrycake.getFormattedDate(),t=document.getElementsByTagName("script");let a="";const r=/berrycake[^\/]*\.js/;for(let s of t){if(s.src.match(r)){a=s.src.replace(r,"")+Berrycake.nameList+`?date=${e}`;break}}return a}checkAndShowBeforeErr=()=>"file:"===window.location.protocol?(this.createWarn("サーバではなくパソコン上のファイルを読み込んでいます。\n設定ファイルを使わない設定に変更するか、サーバ上で動作確認してください。\n※このメッセージはサーバ上では表示されません"),"サーバ上で動作確認してください。"):this.isValidDomain()?null:(this.createWarn("設定ファイルは同一ドメインに配置してください。"),"設定ファイルは同一ドメインに配置してください。");isValidDomain=()=>{if(!(Berrycake.nameList.startsWith("http://")||Berrycake.nameList.startsWith("https://")))return!0;const e=document.createElement("a");e.href=Berrycake.nameList;const t=window.location.hostname;return e.hostname===t};createWarn=e=>{const t=document.createElement("div");t.style.cssText="\n      position: fixed;\n      bottom: 0;\n      left: 0;\n      right: 0;\n      font-size: 12px;\n      background-color: rgb(220, 200, 100);\n      opacity: 0.8;\n      padding: 10px;\n      text-align: center;\n      z-index: 1000;\n    ",t.innerText=e,document.body.appendChild(t)};setNameAndLabel=e=>{e.split("\n").forEach((e=>{const t=e.split("=");if(2!==t.length)return;let a="cake";if(t[0].includes(a)){let e=this.extractNumber(t[0].trim(),a);this.mix[`${a}${e}`]=t[1].replace(/[\r\n]+/g,"")}if(a="label",t[0].includes(a)){let e=this.extractNumber(t[0].trim(),a),r=t[1].replace(/[\r\n]+/g,"").slice(0,10);this.label[`${a}${e}`]=r}}))};createMixForm=()=>{new CreateMixForm(this.label,this.mix,Berrycake.formTargetId,this.extractNumber).generateForm()};extractNumber=(e,t)=>{let a;return"cake"===t&&(a=e.match(/cake(\d+)/)),"label"===t&&(a=e.match(/label(\d+)/)),a?a[1]:null};setTagTarget=()=>{Berrycake.targetAreaId&&(this.targetNode=document.getElementById(Berrycake.targetAreaId),this.targetNode)||Berrycake.targetAreaClass&&(this.targetNode=document.getElementsByClassName(Berrycake.targetAreaClass)[0],this.targetNode)||(this.targetNode=void 0)};addTagList=()=>{this.tags=this.tags.filter((e=>""!==e)),this.addTag=this.addTag.filter((e=>""!==e)),this.tags=[...this.tags,...this.addTag],this.tags=this.tags.map((e=>e.toUpperCase()))};initializeRegexPatterns(){this.regexPatterns={};for(let e in this.mix){const t=this.escapeRegExp(this.mix[e]);this.regexPatterns[e]=new RegExp(t,"g")}}setFormName(e){let t=document.getElementById(e);t&&(t.value=this.cake[e])}setSessionMessage=()=>{let e=document.getElementById(Berrycake.viewRegistSession);e&&(this.isSession?e.textContent=Berrycake.sessionString:e.textContent="")};replaceTextDetail(e){let t=e;if(this.cakeKeys.length){for(let e of this.cakeKeys){const a=this.regexPatterns[e];let r=this.cake[e];r&&(t=t.replace(a,r))}return t}}escapeRegExp(e){return e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}replaceText(e,t){let a=0;const r=e=>{a>=t||e.childNodes.forEach((e=>{a>=t||e.nodeType===Node.ELEMENT_NODE&&e.classList.contains(Berrycake.replaceSkipClass)||(e.nodeType===Node.TEXT_NODE&&this.tags.includes(e.parentNode.nodeName)?(e.textContent=this.replaceTextDetail(e.textContent),a++):e.nodeType===Node.ELEMENT_NODE&&r(e))}))};r(e)}viewName=()=>{if(this.readName(),this.cake){if(this.targetNode){this.replaceText(this.targetNode);new BerrycakeCustom(this.targetNode,this.tags,Berrycake.customNumLimit,Berrycake.customSymbolList,Berrycake.customCommonStr,Berrycake.customSymbol,Berrycake.customNum).applyHandlersToElements()}for(let e in this.cake)this.setFormName(e);this.setSessionMessage()}};readName=()=>{this.isSession=!1;let e,t=null;try{t=JSON.parse(localStorage.getItem(Berrycake.storageKeyName)),t||(t=JSON.parse(sessionStorage.getItem(Berrycake.storageKeyName)),this.isSession=!!t)}catch(a){if(this.isWebAPISupported=!1,e=Object.keys(this.tmpBerrycake),!t&&e.length<1)return!1;if(!t&&e.length>0)for(let t=0;t<e.length;t++){let e=this.cakeKeys[t];this.cake[e]=decodeURIComponent(this.tmpBerrycake[e])}return}if(null===t)return;let a=Object.keys(t);for(let e=0;e<a.length;e++){let r=`cake${this.extractNumber(a[e],"cake")}`;this.cake[r]=decodeURIComponent(t[r])}};unsetNameHandler=()=>{this.unsetStorage(),location.reload(!0)};unsetStorage=()=>{try{localStorage.removeItem(Berrycake.storageKeyName),sessionStorage.removeItem(Berrycake.storageKeyName)}catch(e){return!1}};setNameHandler=e=>()=>{this.setStorage(e)};setStorage(e=!0){let t={};for(let e=0;e<this.cakeKeys.length;e++){let a=this.cakeKeys[e],r=document.getElementById(a);if(!r||r.value.length<1)continue;let s=r.value;void 0!==Berrycake.maxSize&&0!==Berrycake.maxSize&&s.length>Berrycake.maxSize&&(s=s.slice(0,Berrycake.maxSize)+"…"),t[a]=this.tmpBerrycake[a]=encodeURIComponent(s)}try{let a=e?localStorage:sessionStorage,r=e?sessionStorage:localStorage;a.setItem(Berrycake.storageKeyName,JSON.stringify(t)),r.removeItem(Berrycake.storageKeyName),location.reload(!0)}catch(e){Berrycake.showStorageError&&alert("Web Storageが利用できません。ブラウザの設定を確認してください。")}}start=()=>{[{id:Berrycake.setNameId,isLocalStorage:!0,handler:this.setNameHandler(!0)},{id:Berrycake.setSessionId,isLocalStorage:!1,handler:this.setNameHandler(!1)},{id:Berrycake.unsetNameId,isLocalStorage:null,handler:this.unsetNameHandler}].forEach((({id:e,handler:t})=>{const a=document.getElementById(e);a&&(a.removeEventListener("click",t,!1),a.addEventListener("click",t,!1))}))}}class BerrycakeCustom{static customStrList=[{action:"first",handler:"changeFirst",isExclusive:!0},{action:"fold",handler:"changeFold",isExclusive:!0},{action:"split",handler:"changeSplit",isExclusive:!0},{action:"vowel",handler:"changeVowel",isExclusive:!0},{action:"vowel_min",handler:"changeVowelMin",isExclusive:!0},{action:"kana",handler:"changeKana",isExclusive:!1},{action:"hira",handler:"changeHira",isExclusive:!1}];constructor(e,t,a,r,s,i,c){this.targetNode=e,this.tags=t,this.customNumLimit=a,this.customSymbolList=r,this.customCommonStr=s,this.customSymbol=i,this.customNum=c}applyHandlersToElements=()=>{BerrycakeCustom.customStrList.forEach((e=>{this.targetNode.querySelectorAll("."+this.customCommonStr+e.action).forEach((t=>{let a=this.searchOption(t.classList);const r=this[e.handler](t.textContent,a);t.textContent=r}))}))};extractOption=(e,t,a,r)=>{const s=Array.from(e).find((e=>e.startsWith(t)))?.match(/\d+/);let i=s?parseInt(s[0],10):null;return!r&&i>0&&i--,null!==i&&i>a&&(i=r?a:0),i};searchOption=e=>({numVal:this.extractOption(e,this.customNum,this.customNumLimit,!0),symbolVal:this.extractOption(e,this.customSymbol,this.customSymbolList.length-1,!1)});changeFirst=(e,t)=>{const a=this.nameSplit(e),r=t.numVal?t.numVal:1;let s=a[0];for(let e=1;e<r&&(s+=a[e],!(e>=a.length-1));e++);return s};changeFold=(e,t)=>{const a=this.nameSplit(e)[0],r=t.numVal?t.numVal:1;let s=a;for(let e=1;e<r;e++)s+=`、${a}`;return`${s}、`};changeSplit=(e,t)=>{const a=this.nameSplit(e),r=t.symbolVal?this.customSymbolList[t.symbolVal]:this.customSymbolList[0];return a.join(r)};changeVowel=(e,t)=>this.buildVowelString(e,t,!0);changeVowelMin=(e,t)=>this.buildVowelString(e,t,!1);buildVowelString=(e,t,a)=>{let r=e.slice(-1),s=VowelChecker.findRepresentative(r,a);const i=t.numVal?t.numVal:1;let c=s;for(let e=1;e<i;e++)c+=s;return c};changeKana=e=>e.replace(/[\u3041-\u3096]/g,(e=>{let t=e.charCodeAt(0)+96;return String.fromCharCode(t)}));changeHira=e=>e.replace(/[\u30A1-\u30F6]/g,(e=>{let t=e.charCodeAt(0)-96;return String.fromCharCode(t)}));nameSplit=e=>{let t=Array.from(e),a=[];const r=/[ぁぃぅぇぉゕゖっゃゅょゎァィゥェォヵㇰヶㇱㇲッㇳㇴㇵㇶㇷㇸㇹㇺャュョㇻㇼㇽㇾㇿヮｧｨｩｪｫｬｭｮｯ・ー]/;for(let e=0;e<t.length;e++){let s=t[e];for(let a=e+1;a<t.length&&r.test(t[a]);a++)s+=t[a],e++;a.push(s)}return a}}class VowelChecker{static vowelsUppercase=["あ","ア","い","イ","う","ウ","え","エ","お","オ"];static vowelsLowercase=["ぁ","ァ","ぃ","ィ","ぅ","ゥ","ぇ","ェ","ぉ","ォ"];static vowels=[/[あかさたなはまやらわがざだばぱゃぁゕゎ]/,/[アカサタナハマヤラワガザダナパァヵㇵャㇻヮ]/,/[いきしちにひみりゐぎじぢびぃヰ]/,/[イキシチニヒミリギジヂビィㇱㇶㇼ]/,/[うくすつぬふむゆるぐずづぶぷゅぅっ]/,/[ウクスヌヌフムユルグズヅブプュゥㇰㇲッㇴㇷㇽ]/,/[えけせてねへめれゑげぜでべぺぇゖ]/,/[エケセテネヘメレゲゼデベペェヶㇸㇾ]/,/[おこそとのほもよろをごぞどぼぽょぉ]/,/[オコソトノホモヨロヲゴゾドボポョォㇳㇹㇺㇿ]/,/[んー〜ン]/];static findRepresentative=(e,t=!0)=>{let a=null;if(this.vowels.forEach(((t,r)=>{t.test(e)&&(a=r)})),a==this.vowels.length-1)return e;if(null===a)return"";return t?VowelChecker.vowelsUppercase[a]:VowelChecker.vowelsLowercase[a]}}class CreateMixForm{constructor(e,t,a,r){this.elementLabels=e,this.inputProperties=t,this.targetDiv=document.getElementById(a),this.extractNumber=r}static isEmptyObject(e){return 0===Object.keys(e).length&&e.constructor===Object}generateFormElements=()=>{const e=this.targetDiv.classList.contains(Berrycake.formPlainClass);Object.keys(this.inputProperties).forEach((t=>{const a=`label${this.extractNumber(t,"cake")}`;let r="";CreateMixForm.isEmptyObject(this.elementLabels)||(r=this.escapeHTML(this.elementLabels[a])||"");const s=`<label for="${t}">${r}</label><input type="text" id="${t}" value="">`;if(e)this.targetDiv.innerHTML+=s;else{const e=document.createElement("div");e.className="row",e.innerHTML=s,this.targetDiv.appendChild(e)}}))};addButtons=()=>{const e=[{id:Berrycake.setNameId,text:Berrycake.autoSetNameStr},{id:Berrycake.unsetNameId,text:Berrycake.autoUnsetNameStr}],t=document.createElement("div");t.className="row",e.forEach((e=>{const a=document.createElement("button");a.id=e.id,a.textContent=e.text,t.appendChild(a)})),this.targetDiv.appendChild(t)};escapeHTML=e=>e.replace(/[&<>"']/g,(function(e){switch(e){case"&":return"&amp;";case"<":return"&lt;";case">":return"&gt;";case'"':return"&quot;";case"'":return"&#39;";default:return e}}));generateForm(){this.targetDiv&&(this.generateFormElements(),this.addButtons())}}try{Berrycake.run()}catch(e){console.error("An error occurred while creating a Berrycake instance: ",e)}